import tkinter as tk
import ttkbootstrap as ttk
import welcomepage
# from welcomepage import WelcomePage
import creating_files



def main():
    global root_welcomepage
    creating_files.create_folder_files()
    root_welcomepage = ttk.Window(themename="purpletheme")
    welcomepage.WelcomePage(root_welcomepage)
    root_welcomepage.mainloop()     

if __name__ == "__main__":
    main()


