import tkinter as tk
import ttkbootstrap as ttk
import creating_files
# from journal import datepicked
import journal


def giannisapp():
    global app_giannis

    class App:
        def __init__(self, root):
            super().__init__()
            self.w = root
            self.w.resizable(0, 0)
            self.w.geometry("763x840")  # Θέτω το μέγεθος του παραθύρου σε 800x775
            self.w.title("Mind at Ease")  # Ορίζω τον τίτλο του παραθύρου
            self.w.configure(bg="#e1c9f8")  # Ορίζω το χρώμα του παραθύρου
            self.entries = (
                []
            )  # Δημιουργώ μια νέα λίστα που θα περιέχει όλα τα entry πεδία που θα δημιουργηθούν στην ενέργεια του κώδικα
            self.entrysave = (
                []
            )  # list that contains the value of each entrybox when you press the button save
            self.variables = []  # list that contains stringvars
            self.textvar = ""  # variable that contains the value of the text widget
            self.listatoutext = []
            self.frame1 = Frame1(self.w, self)
            self.frame1.grid(
                row=0, column=0, columnspan=3, sticky="news"
            )  # Τοποθετώ το πρώτο πλαίσιο στο παράθυρο
            self.frame2 = Frame2(self.w, self)
            self.frame2.grid(
                row=1, column=0, rowspan=2, columnspan=3, sticky="news"
            )  # Τοποθετώ το δεύτερο πλαίσιο στο παράθυρο
            self.frame3 = Frame3(self.w, self)
            self.frame3.grid(
                row=3, column=0, columnspan=3, sticky="news"
            )  # Τοποθετώ το τρίτο πλαίσιο στο παράθυρο

        def savee(self):
            for i in self.entries:
                self.entrysave.append(i.get())
            self.textvar = self.listatoutext[0].get(0.1, "end")

    class Frame1(tk.Frame):
        def __init__(self, parent, app):
            super().__init__(
                parent, bg="#e1c9f8"
            )  # Φτιάχνει το πρώτο πλαίσιο με parent widget
            self.label1 = ttk.Label(
                self,
                text="Fill in the blanks with the prevailing emotions of the day :",
                font=("Helvetica", 10),
                bootstyle="primary-inverse",
            )  # Φτιάχνει μια ταμπέλα με ένα καθορισμένο κείμενο
            self.label1.grid(
                row=0, column=1, columnspan=3, sticky="news", padx=125
            )  # Τοποθετώ την ταμπέλα
            self.app = app
            self.entries = (
                []
            )  # Δημιουργώ μια νέα λίστα που θα περιέχει όλα τα entry πεδία που θα δημιουργηθούν στην ενέργεια του κώδικα
            self.entrysave = []  # lista poy periexei ta periexomena ton entries
            self.variables = []

            for i in range(
                5
            ):  # Τοποθετώ μέσα σε μια σειρά τα παρακάτω widget για να αποφύγω την επανάληψη τους
                self.lbl = ttk.Label(
                    self, text="•"
                )  # Δημιουργώ μια ταμπέλα με "•" σαν κείμενο
                self.lbl.grid(
                    row=i + 1, column=0, sticky="w", padx=20
                )  # Τοποθετώ την ταμπέλα
                text = tk.StringVar(value="")
                self.app.variables.append(text)
                self.entry = ttk.Entry(
                    self,
                    width=30,
                    font=("Helvetica", 10),
                    bootstyle="danger",
                    textvariable=text,
                )
                self.entry.grid(row=i + 1, column=1, sticky="news", padx=10, pady=10)
                self.entry.bind("<Key>", self.char_limit)
                self.app.entries.append(self.entry)

            # Κάνω ακριβώς το ίδιο και για τη δεύτερη στήλη
            for i in range(5):
                self.lbl = ttk.Label(self, text="•")
                self.lbl.grid(row=i + 1, column=2, sticky="w", padx=20)
                text = tk.StringVar(value="")
                self.app.variables.append(text)
                self.entry = ttk.Entry(
                    self,
                    width=30,
                    font=("Helvetica", 10),
                    bootstyle="danger",
                    textvariable=text,
                )
                self.entry.grid(row=i + 1, column=3, sticky="news", padx=10, pady=10)
                self.entry.bind(
                    "<Key>", self.char_limit
                )  # Μια ενέργεια που γίνεται κάθε φορά που πατά ο χρήστης μια πλήκτρο στο entry πεδίο. Αυτή η ενέργεια καλεί την συνάρτηση self.char_limit κάθε φορά που πατά ο χρήστης ένα πλήκτρο
                self.app.entries.append(
                    self.entry
                )  # μια ενέργεια που προσθέτει το entry πεδίο στη λίστα self.entries. Αυτό το γίνεται για να διατηρηθεί η λίστα με όλα τα entry πεδία που δημιουργήθηκαν

        def char_limit(
            self, event
        ):  # Η συνάρτηση που βάζει όριο στους χαρακτήρες που μπορούν να πληκτρολογηθούν στα entry box.
            entry_widget = (
                event.widget
            )  # Προσδιορίζει ποιό entry box έχει ενεργοποιηθεί και το εκχωρεί στην μεταβλητή entry_widget
            input_str = (
                entry_widget.get()
            )  # Θέτω ως input_str 'ο,τι έχει γράψει ο χρήστης στα entry box
            if (
                len(input_str) > 13
            ):  # Ελέγχει εάν το μήκος του string είναι μεγαλύτερο των 15 χαρακτήρων
                entry_widget.delete(
                    0, "end"
                )  # Διαγράφει όλο το περιεχόμενο του entry πεδίου από την θέση 0 μέχρι το τέλος.
                entry_widget.insert(
                    0, input_str[:15]
                )  # Καλείται μετά τη διαγραφή του περιεχόμενου του entry πεδίου για να εισάγει το νέο περιεχόμενο.

    class Frame2(tk.Frame):
        def __init__(self, parent, app):
            super().__init__(
                parent, bg="#e1c9f8"
            )  # Φτιάχνει το δεύτερο πλαίσιο με parent widget
            self.label2 = ttk.Label(
                self,
                text="Elaborate further on these feelings !",
                font=("Helvetica", 10),
                bootstyle="primary-inverse",
            )  # Φτιάχνει μια ταμπέλα με ένα καθορισμένο κείμενο
            self.label2.grid(
                row=0, column=0, columnspan=3, sticky="news", pady=2, padx=250
            )  # Τοποθετώ την ταμπέλα
            self.app = app
            self.text = ttk.Text(
                self, font=("Helvetica", 10), width=80, height=23
            )  # Δημιουργώ ένα text widget, στο οποίο ο χρήστης μπορεί να πληκρολογήσει ελεύθερα τις σκέψεις του
            self.text.grid(
                row=1, column=0, sticky="news", rowspan=1, columnspan=3, padx=10
            )  # Τοποθετώ το widget
            self.listatoutext = []
            self.app.listatoutext.append(self.text)
            self.clear_all_button = ttk.Button(
                self,
                text="Clear Text",
                bootstyle="warning-link",
                width=85,
                command=self.clear_all,
            )
            self.clear_all_button.grid(row=2, column=0, columnspan=1, sticky="se")

        def clear_all(self):
            self.text.delete(1.0, "end")

    class Frame3(tk.Frame):
        def __init__(self, parent, app):
            super().__init__(
                parent, bg="#e1c9f8"
            )  # Φτιάχνει το τρίτο πλαίσιο με parent widget
            self.button1 = ttk.Button(
                self,
                text="Save & Quit",
                bootstyle="primary",
                command=self.save_and_quit_window,
            )  # Δημιουργώ ενα κουμπί "Save", το οποίο όταν πατηθεί αποθηκεύει ό,τι έχει γράψει ο χρήστης
            self.button1.grid(
                row=1, column=3, sticky="news", padx=555, pady=3
            )  # Τοποθετώ το κουμπί στο πλαίσιο
            self.app = app
            self.button2 = ttk.Button(
                self, text="Exit", bootstyle="primary", command=self.exit_window
            )  # Δημιουργώ ένα κουμπί "Exit", το οποίο όταν πατηθεί κλείνει το παράθυρο
            self.button2.grid(
                row=1, column=1, sticky="news", padx=15, pady=3
            )  # Τοποθετώ το κουμπί στο πλαίσιο

        def exit_window(self):
            self.master.destroy()  # Δημιουργώ την συνάρτηση για το κουμπί "Exit" , η οποία κλείνει το παράθυρο

        def save_and_quit_window(self):
            global datepicked
            self.app.savee()  # Δημιουργώ την συνάρτηση για το κουμπί "Save & Quit", η οποία αποθηκεύει τα στοιχεία του παραθύρου και το κλείνει
            creating_files.create_folder_files()
            datepicked = journal.appopen.getdate()
            creating_files.save_file(datepicked)  # checkpoint
            self.master.destroy()

    # Δημιουργώ το παράθυρο, και βάζω ένα συγκεκριμένο theme
    root = ttk.Toplevel()
    app_giannis = App(root)
    # Θέτω ως παράμετρο της κλάσης App το ίδιο το παράθυρο, ώστε η κλάση αυτή να είναι υπεύθυνη για το περιεχόμενο και τη λειτουργικότητα του παραθύρου
    # root.mainloop() # Με αυτή τη μέθοδο ξεκινάει ο βρόχος επεξεργασίας γεγονότων


# app_giannis.entrysave
# app_giannis.textvar
    